from elasticsearch.client import IndicesClient
from django.conf import settings
from django.core.management.base import BaseCommand
from homepage.models import Organization, RecreationalActivity
from elasticsearch.helpers import bulk

class Command(BaseCommand):
	def add_arguments(self,parser):
		parser.add_argument('index_type')

	def handle(self, *args, **options):
		index_type = options['index_type']

		if index_type == 'organization':
			self.recreate_index(index_type)
			self.push_db_to_index(index_type)

	def recreate_index(self,idx_type):
		indices_client = IndicesClient(client=settings.ES_CLIENT)
		if idx_type == 'organization':
			index_name = Organization._meta.es_index_name	
		elif idx_type == 'recreational_activity':
			index_name = RecreationalActivity._meta.es_index_name	

		if indices_client.exists(index_name):
			indices_client.delete(index=index_name)
		indices_client.create(index=index_name)

		if idx_type == 'organization':
			indices_client.put_mapping(
	            doc_type=Organization._meta.es_type_name,
	            body=Organization._meta.es_mapping,
	            index=index_name
	        )
	    elif idx_type == 'recreational_activity':    
	    	indices_client.put_mapping(
	            doc_type=RecreationalActivity._meta.es_type_name,
	            body=RecreationalActivity._meta.es_mapping,
	            index=index_name
	        )

	def push_db_to_index(self,idx_type):
		if idx_type == 'organization':
			data = [self.convert_for_bulk(s, 'create') for s in Organization.objects.all()]
			bulk(client=settings.ES_CLIENT, actions=data, stats_only=True)
		elif idx_type == 'recreational_activity':	
			data = [self.convert_for_bulk(s, 'create') for s in RecreationalActivity.objects.all()]
			bulk(client=settings.ES_CLIENT, actions=data, stats_only=True)

	def convert_for_bulk(self, django_object, action=None):
		data = django_object.es_repr()
		metadata = {
            '_op_type': action,
            "_index": django_object._meta.es_index_name,
            "_type": django_object._meta.es_type_name,
        }
		data.update(**metadata)
		return data